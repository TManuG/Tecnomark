import Products from './products';
import Users from './users';
import Records from './records'
const Routes = {
    Products,
    Users,
    Records
}
export default Routes;